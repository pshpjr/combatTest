#pragma once
#include "Define.h"

namespace psh::EventSystem
{
	using CallbackID = uint32;
	inline CallbackID InvalidCallbackID = 0xffffffff;
}
